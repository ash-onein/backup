import re
import lxml
import justext
from bs4 import BeautifulSoup
from gevent import lock
# from common.utils.log import Logger

# logging = Logger.getLogger(__file__)


class TextProcessing(object):
    _instance = None
    _lock = lock.RLock()

    @classmethod
    def get_instance(cls):
        if not TextProcessing._instance:
            with cls._lock:
                if not TextProcessing._instance:
                    TextProcessing._instance = TextProcessing()
        return TextProcessing._instance

    def __init__(self):
        self._RE_NUMBERS = re.compile(r'\d')
        self._NUMBER_REPLACEMENT = 'D'

    def __clean_web_script(self, text):
        if text is None or text == '' or not isinstance(text, str):
            logging.exception("text is None or ''")
            return None
        try:
            cleaned_parts = justext.justext(text, justext.get_stoplist('English'))
            cleaned_parts = [p.text for p in cleaned_parts]
            cleaned_parts = " ".join(cleaned_parts)
            return cleaned_parts
        except lxml.etree.ParserError as e:
            logging.exception(f"lxml parse error on text - {text} \n\n Error: {e}")
            return None
        except UnicodeDecodeError as e:
            logging.exception(f"unicode decode error on text - {text} \n\n Error: {e}")
            return None
        except Exception as e:
            logging.exception(f"unhandled error on text - {text} \n\n Error: {e}")
            return None

    def clean_numbers(self, text):
        if not isinstance(text, str) or text == '' or text is None:
            return ''
        text = re.sub(self._RE_NUMBERS, self._NUMBER_REPLACEMENT, text)
        return text

    def __clean_text_bs4(self, text):
        text = text.strip().strip('\n')
        text = re.sub(r'\n+', '\n', text).strip()
        text = re.sub(r'\s\s+', ' ', text)
        return text

    def __html_text_bs4(self, htmltxt):
        if not htmltxt: return ''
        try:
            soup = BeautifulSoup(htmltxt, 'html.parser')
            for s in soup.select('script'):  # remove js from html
                s.extract()
            text = soup.get_text(separator="\n")
            text_clean = self.__clean_text_bs4(text).replace("\n", "")
        except:
            text_clean = ''
        return text_clean

    def clean_html_bs4(self, text):
        if text is None or text == '' or not isinstance(text, str):
            return ''
        html_cleaned_text = self.__html_text_bs4(text)
        if html_cleaned_text == '':
            html_cleaned_text = self.__clean_web_script(text)
            if html_cleaned_text is None:
                html_cleaned_text = ''
        return html_cleaned_text

    def clean_html(self, text):
        if text is None or text == '' or not isinstance(text, str):
            return ''
        html_cleaned_text = self.__clean_web_script(text)
        if html_cleaned_text is None:
            html_cleaned_text = self.__html_text_bs4(text)
        return html_cleaned_text

    def process(self, text):
        if text is None or text == '' or not isinstance(text, str):
            return ''
        text = self.clean_html(text)
        text = self.clean_numbers(text)
        return text

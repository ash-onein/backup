import re
import emoji
from gevent import lock
from bs4 import BeautifulSoup
from mosestokenizer import MosesSentenceSplitter

import sentence_tokenize
# from common.utils.log import Logger

# logging = Logger.getLogger(__file__)


class TextProcessingHelperFunctions(object):
    _instance = None
    _lock = lock.RLock()

    @classmethod
    def get_instance(cls):
        if not TextProcessingHelperFunctions._instance:
            with cls._lock:
                if not TextProcessingHelperFunctions._instance:
                    TextProcessingHelperFunctions._instance = TextProcessingHelperFunctions()
        return TextProcessingHelperFunctions._instance

    def __init__(self):
        self._RE_NUMBERS = re.compile(r'\d')
        self._RE_URL = r'((http|https)\:\/\/)?[a-zA-Z0-9\.\/\?\:@\-_=#]+\.([a-zA-Z]){2,6}([a-zA-Z0-9\.\&\/\?\:@\-_=#])*'
        self._RE_NON_ASCII_CHARS = r'[^\x00-\x7F₹]+'
        self._RE_ALLOWED_CHARS = {
            'en': r'[^\x00-\x7F₹]+',
            'hi': r'[^\u0900-\u097F\x00-\x7F₹]+',
            'ml': r'[^\u0D00-\u0D7F\x00-\x7F₹]+',
            'te': r'[^\x00-\x7F₹\u0C00-\u0C7F]+',
            'mr': r'[^\u0900-\u097F\x00-\x7F₹]+',
            'or': r'[^\u0B00-\u0B7F\x00-\x7F₹]+',
            'ta': r'[^\x00-\x7F₹\u0B80-\u0BFF]+',
            'kn': r'[^\x00-\x7F₹\u0C80-\u0CFF]+',
            'pa': r'[^\u0A00-\u0A7F\x00-\x7F₹]+',
            'bn': r'[^\u0980-\u09FF\x00-\x7F₹]+',
            'gu': r'[^\u0A80-\u0AFF\x00-\x7F₹]+',
        }
        self._RE_MULTIPLE_SPACES = r'\s\s+'
        self._RE_SPECIAL_CHARS = r'([!"₹#$%&\'()*+,./:;<=>?@\[\]^_`{|}~])'
        self._RE_INSTAGRAM_TWITTER_HANDLES = r'([!"₹#$%&\'()*+,./:;<=>?@\[\]^_`{|}~\s]+)(@[A-Za-z0-9._%+-]{1,50})'
        self._RE_EMAIL = r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,6}'

        self._DEFAULT_SENTENCE_ENDERS = {'en': '.', 'mr': '.',
                                         'ta': '.', 'te': '.',
                                         'kn': '.', 'ml': '.',
                                         'hi': '।', 'bn': '।',
                                         'pa': '।', 'or': '|',
                                         'as': '|'}

        self._SENT_END_CHARS = {'!': 1, '.': 1, ';': 1, '?': 1, "।": 1, "|": 1}
        self._INDIC_LANGS = {"as": 1, "bn": 1, "gu": 1,
                             "hi": 1, "kn": 1, "ml": 1,
                             "mr": 1, "or": 1, "pa": 1,
                             "ta": 1, "te": 1}

    def remove_emoji(self, text):
        text = emoji.get_emoji_regexp().sub('', text)
        return text

    def clean_instagram_twitter_handels(self, text):
        text = re.sub(self._RE_INSTAGRAM_TWITTER_HANDLES, r'\1', text)
        return text

    def clean_emails(self, text):
        text = re.sub(self._RE_EMAIL, '', text)
        return text

    def clean_multiple_spaces(self, text):
        text = re.sub(self._RE_MULTIPLE_SPACES, ' ', text)
        return text

    def clean_non_ascii(self, text):
        text = re.sub(self._RE_NON_ASCII_CHARS, '', text)
        return text

    def clean_non_relevant_chars(self, text, language):
        if text is None or text == '':
            return ''
        text = re.sub(self._RE_ALLOWED_CHARS.get(language), '', text)
        return text

    def clean_urls(self, text):
        text = re.sub(self._RE_URL, "", text)
        return text

    def clean_text_bs4(self, text):
        text = text.strip().strip('\n')
        text = re.sub(r'\n+', ' ', text).strip()
        text = re.sub(r'\r+', ' ', text).strip()
        text = re.sub(r' +', ' ', text).strip()
        return text

    def html_text_bs4(self, htmltxt):
        if not htmltxt: return ''
        try:
            soup = BeautifulSoup(htmltxt, 'html.parser')
            for s in soup.select('script'):  # remove js from html
                s.extract()
            text = soup.get_text(separator="\n")
            text_clean = self.clean_text_bs4(text).replace("\n", "")
        except:
            text_clean = ''
        return text_clean

    def separate_special_characters(self, text):
        text = re.sub(self._RE_SPECIAL_CHARS, r' \1 ', text)
        return text

    def clean_numbers(self, text, NUMER_REPLACEMENT='D'):
        cleaned_text = re.sub(self._RE_NUMBERS, NUMER_REPLACEMENT, text)
        return cleaned_text

    def put_sentence_enders(self, text, languauge, default_sentence_ender=None):
        if default_sentence_ender is None:
            default_sentence_ender = self._DEFAULT_SENTENCE_ENDERS.get(languauge, '.')
        text = text.strip()
        if len(text) > 0:
            if text[-1] not in self._SENT_END_CHARS:
                text += default_sentence_ender
        return text

    def remove_dailyhunt(self, text):
        if text is None or text == '' or not isinstance(text, str):
            return ''

        text = re.sub(r'Dailyhunt', '', text, flags=re.IGNORECASE)
        # text = text.rstrip('oneindia.com')
        text = re.sub(r'oneindia.com','',text,flags=re.IGNORECASE)

        # # dummy at the end of every page html text, removeds
        # if text.endswith('Dailyhunt') or text.endswith("dailyhunt"):
        #     text = text[:-10]
        
        return text

    def split_sentences(self, paragraph, language):
        if language == "en":
            with MosesSentenceSplitter(language) as splitter:
                return splitter([paragraph])
        elif language in self._INDIC_LANGS:
            return sentence_tokenize.sentence_split(paragraph, lang=language)

    def check_if_last_char_sentence_ender(self, text):
        if len(text) > 0:
            char = text[-1]
            if char in self._SENT_END_CHARS:
                return True
            return False
        else:
            return False

    def remove_nsbp(self, text):
        text = text.replace('\u200b', '').strip()
        return text


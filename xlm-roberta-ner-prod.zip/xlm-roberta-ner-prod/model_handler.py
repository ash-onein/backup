import logging
import transformers
import os
import json
# import regex as re
from ts.torch_handler.base_handler import BaseHandler
import torch
from bs4 import BeautifulSoup
import re
import string
from indicnlp.tokenize import sentence_tokenize

import emoji
from helper_functions import TextProcessingHelperFunctions
from text_preprocessing import TextProcessing
import itertools

from fuzzywuzzy import fuzz
from transformers import AutoTokenizer, pipeline, AutoModelForTokenClassification

# creating a logger
logger = logging.getLogger(__name__)
logger.info("Transformers version %s", transformers.__version__)

patterns = {
    'te': {
        'mathra_pattern': b'[\\u0c3e-\\u0c4c]|[\\u0c00-\\u0c04]|[\\u0c62-\\u0c63]|\\u0c4d'.decode('unicode_escape'),
        'base_pattern': b'[\\u0c05-\\u0c39]'.decode('unicode_escape')
    },
    'bn': {
        'mathra_pattern': b'[\\u09be-\\u09c8]|[\\u0980-\\u0983]|[\\u09cb-\\u09cc]|\\u09cd'.decode('unicode_escape'),
        'base_pattern': b'[\\u0985-\\u09b9]'.decode('unicode_escape')
    },
    'gu': {
        'mathra_pattern':b'[\\u0abe-\\u0acc]|[\\u0a81-\\u0a83]|[\\u0abc-\\u0abd]|\\u0acd'.decode('unicode_escape') ,
        'base_pattern': b'[\\u0a85-\\u0ab9]'.decode('unicode_escape')
    },
    'kn': {
        'mathra_pattern':b'[\\u0cbe-\\u0ccd]|[\\u0c80-\\u0c84]|\\0cd5|\\0cd6|\\0ce2|\\0ce3'.decode('unicode_escape'),
        'base_pattern': b'[\\u0c85-\\u0cb9]'.decode('unicode_escape')
    },
    'ml': {
        'mathra_pattern':b'[\\u0d3e-\\u0d48]|[\\u0d00-\\u0d04]|[\\u0d4a-\\u0d4d]|\\u0d57'.decode('unicode_escape'),
        'base_pattern': b'[\\u0d05-\\u0d3a]'.decode('unicode_escape')
    },
    'mr': {
        'mathra_pattern':b'[\\u093e-\\u094c]|[\\u0900-\\u0903]|[\\u094e-\\u094f]|\\u094d|\\u0972'.decode('unicode_escape'),
        'base_pattern': b'[\\u0904-\\u0939]'.decode('unicode_escape')
    },
    'or': {
        'mathra_pattern':b'[\\u0b3e-\\u0b4c]|[\\u0b01-\\u0b03]|[\\u0b3c-\\u0b3d]|[\\u0b62-\\u0b63]|\\u0b4d'.decode('unicode_escape'),
        'base_pattern': b'[\\u0b05-\\u0b39]'.decode('unicode_escape')
    },
     'pa': {
        'mathra_pattern':b'[\\u0A3E-\\u0A4C]|[\\u0A01-\\u0A03]||\\u0A3C|\\u0A4D'.decode('unicode_escape'),
        'base_pattern': b'[\\u0A05-\\u0A39]|[\\u0A59-\\u0A5E]'.decode('unicode_escape')
    },
    'ta': {
        'mathra_pattern':b'[\\u0bbe-\\u0bcd]|[\\u0b82-\\u0b83]|[\\u0bd0-\\u0bd7]'.decode('unicode_escape'),
        'base_pattern': b'[\\u0b85-\\u0bb9]'.decode('unicode_escape')
    },
    
}

__RE_URL = r'((http|https)\:\/\/)?[a-zA-Z0-9\.\/\?\:@\-_=#]+\.([a-zA-Z]){2,6}([a-zA-Z0-9\.\&\/\?\:@\-_=#])*'

__RE_NON_HINDI_WITH_DOT = r"(\b[^\u0900-\u097f]+)\."
__RE_SENTENCE_BREAK = r'।|\?|!|\.'
__RE_HINDI = r'[^\u0900-\u097f]'
__RE_HINDI_WITH_SPACE = r'[^\u0900-\u097f\s]'
LEN_CHUNK_1 = 100
__MAX_NUM_CALLS = 10

def __get_mismatch_scores(char_tuple_list,language):
    score = 0.0
    if char_tuple_list:
        for ele in char_tuple_list:
            rule_1 = [((ele[0] == None) and (ele[1] == '\u200d')),
                        ((ele[0] == '\u200d') and (ele[1] == None)),
                        ((ele[0] == None) and re.match(patterns[language]['base_pattern'], ele[1])),
                        (re.match(patterns[language]['base_pattern'], ele[0]) and (ele[1] == None)),
                        ((ele[0] == None) and re.match(patterns[language]['mathra_pattern'], ele[1])),
                        ((re.match(patterns[language]['mathra_pattern'], ele[0])) and (ele[1] == None)),
                        (re.match(patterns[language]['mathra_pattern'], ele[0]) and re.match(
                            patterns[language]['mathra_pattern'], ele[1])),
                        ]

            rule_2 = [((ele[0] == '') and re.match(patterns[language]['base_pattern'], ele[1])),
                        (re.match(patterns[language]['base_pattern'], ele[0]) and (ele[1] == '')),
                        ((re.match(patterns[language]['mathra_pattern'], ele[0])) and (ele[1] == '')),
                        ((ele[0] == '') and re.match(patterns[language]['mathra_pattern'], ele[1])),
                        ]

            rule_3 = [(ele[0] == '\u200d' and re.match(patterns[language]['base_pattern'], ele[1])),
                        (re.match(patterns[language]['base_pattern'], ele[0]) and ele[1] == '\u200d'),
                        ((ele[0] == ' ') and re.match(patterns[language]['base_pattern'], ele[1])),
                        (re.match(patterns[language]['base_pattern'], ele[0]) and (ele[1] == ' ')),
                        ((re.match(patterns[language]['mathra_pattern'], ele[0])) and (ele[1] == ' ')),
                        ((ele[0] == ' ') and re.match(patterns[language]['mathra_pattern'], ele[1])),
                        ((ele[0] in string.punctuation) and re.match(
                            patterns[language]['mathra_pattern'], ele[1])),
                        ((re.match(patterns[language]['mathra_pattern'], ele[0])) and (
                                ele[1] in string.punctuation)),
                        ((ele[0] in string.punctuation) and re.match(patterns[language]['base_pattern'],
                                                                    ele[1])),
                        ((re.match(patterns[language]['base_pattern'], ele[0])) and (
                                ele[1] in string.punctuation)),
                        (re.match(patterns[language]['base_pattern'], ele[0]) and re.match(
                            patterns[language]['base_pattern'], ele[1])),
                        (re.match(patterns[language]['base_pattern'], ele[0]) and re.match(
                            patterns[language]['mathra_pattern'], ele[1])),
                        (re.match(patterns[language]['mathra_pattern'], ele[0]) and re.match(
                            patterns[language]['base_pattern'], ele[1])),
                        ]

            if any(rule_1):
                score += 0.5
            elif any(rule_2):
                score += 0.25
            elif any(rule_3):
                score += 1
        return score


def __calculate_mismatch(ele_i, ele_j,language):
    if len(ele_i) >= 3 and len(ele_j) >= 3 and ele_i[:3] == ele_j[:3]:
        if ele_i == ele_j:
            return True
        char_tuple_list = [(c1, c2) for c1, c2 in list(itertools.zip_longest(ele_i, ele_j)) if c1 != c2]
        char_tuple_list = [(tuple('' if x is None else x for x in tup)) for tup in char_tuple_list]
        score = __get_mismatch_scores(char_tuple_list,language)
        if score > 2.5:
            return False
        return True
    else:
        return False


def __calculate_mismatch_caller(ele_i, ele_j,language):
    match = False

    if not ele_i or not ele_j:
        return False

    ele_i_arr = ele_i.split(" ")
    ele_j_arr = ele_j.split(" ")

    proceed = False
    for ele_i_token in ele_i_arr:
        for ele_j_token in ele_j_arr:
            if ele_i_token and ele_j_token and ele_i_token[0] == ele_j_token[0]:
                proceed = True

    if not proceed:
        return False

    fuzz_ratio = fuzz.ratio(ele_i, ele_j)

    if fuzz_ratio >= 70:
        return True
    else:
        min_len = min(len(ele_i), len(ele_j))
        if min_len > 6:
            fuzz_ratio = fuzz.ratio(ele_i[:min_len], ele_j[:min_len])
            if fuzz_ratio >= 75:
                return True

        match = __calculate_mismatch(ele_i, ele_j,language)
        if not match and ele_i != ele_j:
            small_element = ele_i if len(ele_i) < len(ele_j) else ele_j
            big_element = ele_i if len(ele_i) >= len(ele_j) else ele_j
            try:
                if re.search(rf"[\b ]{small_element}[\b ]", ' ' + big_element + ' '):
                    match = True
            except:
                pass
    return match

    
def match_entities(entities,language):
    token_list = list(entities)

    tokens_set = [-1] * len(token_list)
    num_sets = 0
    for idx in range(len(token_list)):
        ele_i = token_list[idx]
        for jdx in range(idx + 1, len(token_list)):
            ele_j = token_list[jdx]
            match = __calculate_mismatch_caller(ele_i, ele_j,language)
            if match:
                if tokens_set[idx] == -1 and tokens_set[jdx] == -1:
                    tokens_set[idx] = num_sets
                    tokens_set[jdx] = num_sets
                    num_sets += 1
                elif tokens_set[idx] == -1 and tokens_set[jdx] != -1:
                    tokens_set[idx] = tokens_set[jdx]
                elif tokens_set[idx] != -1 and tokens_set[jdx] == -1:
                    tokens_set[jdx] = tokens_set[idx]
                if tokens_set[idx] != -1 and tokens_set[jdx] != -1:
                    set_num = min(tokens_set[idx], tokens_set[jdx])
                    to_replace = max(tokens_set[idx], tokens_set[jdx])
                    tokens_set = [x if x != to_replace else set_num for x in tokens_set]

    if len(token_list) <= 0:
        return {}

    len_sets = max(tokens_set) + 1
    sets = [set() for _ in range(len_sets)]
    sets_individual = []

    for element, set_num in zip(token_list, tokens_set):
        if set_num != -1:
            sets[set_num].add(element)
        else:
            sets_individual.append(set([element]))
    sets.extend(sets_individual)

    ner_dicts = {}
    for set_ in sets:
        smallest_len = float('inf')
        smallest_word = ''
        for ner in set_:
            len_ner = len(ner)
            if len_ner < smallest_len:
                smallest_word = ner
                smallest_len = len_ner
        if smallest_word:
            ner_dicts[smallest_word] = list(set_)
    return ner_dicts


def replace_char(word, language, irr_char):
    # print(word)
    return re.sub(irr_char[language], "", word)


def recreate_ners(sample, language, irr_char):
    i, word_tuples = 0, []
    while i <= len(sample) - 1:
        j = i + 1
        res = replace_char(sample[i]["word"], language, irr_char)
        while j < len(sample) and sample[j]["start"] - sample[i]["end"] < 2:
            if sample[j]["entity"] != sample[i]["entity"]:
                break
            _diff = sample[j]["start"] - sample[i]["end"]
            if _diff == 0:
                res += replace_char(sample[j]["word"], language, irr_char)
            else:
                res = " ".join(
                    [res, replace_char(sample[j]["word"], language, irr_char)]
                )
            i, j = j, j + 1
        word_tuples.append(res)
        i += 1
    return word_tuples

def dedup_ne_list(ners):
    ners_names = {}
    ners.sort(key=lambda s: len(s))
    for ne in ners:
        keep1 = True
        if len(ne.split()) < 2:
            for ne2 in ners:
                keep2 = True
                try:
                    if ne != ne2 and re.search(rf"\b{ne}\b", ne2):
                        keep2 = False
                        keep1 = False
                except:
                    continue
                if not keep2:
                    if ne2 in ners_names:
                        ners_names[ne2].append(ne)
                    else:
                        ners_names[ne2] = [ne]

        if keep1:
            if ne in ners_names:
                ners_names[ne].append(ne)
            else:
                ners_names[ne] = [ne]
    ners_names = {ne: list(set(ners_names[ne])) for ne in ners_names.keys()}
    return ners_names



def get_percentage_engish(text):
    hindi_text = re.sub(__RE_HINDI, '', text)
    return 1 - len(hindi_text) / len(text) if len(text) > 0 else 0

def remove_english(text):
    text = re.sub(__RE_HINDI_WITH_SPACE, '', text)
    text = re.sub(r'\s\s+', ' ', text)
    return text


def get_custom_chunks(html_chunk_1, html_chunk_2):
    html_chunk_1 = re.sub(__RE_NON_HINDI_WITH_DOT, r"\1", html_chunk_1)
    html_chunk_2 = re.sub(__RE_NON_HINDI_WITH_DOT, r"\1", html_chunk_2)

    body = html_chunk_1 + " । " + html_chunk_2

    sentences = re.split(__RE_SENTENCE_BREAK, body)

    custom_chunk_1 = []
    custom_chunk_2 = []
    chunk_1_len = 0

    for sentence in sentences:
        sentnce = sentence.strip()
        english_chars_percentage = get_percentage_engish(sentence.replace(" ", ""))
        if english_chars_percentage >= 0.5:
            sentence = remove_english(sentnce)

        words = sentence.split(" ")
        if len(words) + chunk_1_len <= LEN_CHUNK_1:
            custom_chunk_1.append(sentence)
            chunk_1_len += len(words)
        else:
            custom_chunk_2.append(sentence)
            chunk_1_len += len(words)

    custom_chunk_1 = "। ".join(custom_chunk_1)
    custom_chunk_2 = "। ".join(custom_chunk_2)

    return custom_chunk_1, custom_chunk_2



def lowercase_dict_keys_and_values(data):
    if isinstance(data, dict):
        new_data = {}
        for key, value in data.items():
            new_key = key.lower()
            if isinstance(value, (str, list)):
                new_value = [v.lower() if isinstance(v, str) else v for v in value]
            else:
                new_value = lowercase_dict_keys_and_values(value)
            new_data[new_key] = new_value
        return new_data
    elif isinstance(data, list):
        return [lowercase_dict_keys_and_values(item) for item in data]
    else:
        return data

def preprocess_span(text):
    soup = BeautifulSoup(text, 'html.parser')
    span_element = soup.find('span', class_='dhFirstAkshar')
    if span_element:
        replacement_text = span_element.text
    
        # Replace the entire <span> element with just the replacement text
        span_element.replace_with(replacement_text)
    
    # Get the modified HTML content
    modified_html = str(soup)
    return modified_html

def indic_preprocessing(text,lang):
    text = TextProcessingHelperFunctions.get_instance().html_text_bs4(text)
    text = TextProcessingHelperFunctions.get_instance().clean_urls(text)
    text = TextProcessingHelperFunctions.get_instance().remove_dailyhunt(text)
    text = TextProcessingHelperFunctions.get_instance().remove_emoji(text)
    text = TextProcessingHelperFunctions.get_instance().clean_instagram_twitter_handels(text)
    text = TextProcessingHelperFunctions.get_instance().clean_emails(text)
    text = TextProcessingHelperFunctions.get_instance().clean_multiple_spaces(text)
    text = TextProcessingHelperFunctions.get_instance().clean_non_relevant_chars(text,lang)
    text = TextProcessingHelperFunctions.get_instance().remove_nsbp(text)
    return text

# custom  model handler class
class ModelHandler(BaseHandler):
    def initialize(self, context):
        properties = context.system_properties
        # logger.info(f'properties:{properties}')
        self.manifest = context.manifest
        model_dir = properties.get("model_dir")  # the temporary directory in which the model.bin file is saved
        
        # use GPU if available
        self.device = "cuda:0" if torch.cuda.is_available() else "cpu"  # if the inferencing maching got GPU it will automatically load it
        self.model = AutoModelForTokenClassification.from_pretrained(model_dir)
        self.model.to(self.device)
        
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir + "/")
        self.classifier = pipeline("ner", model=self.model, tokenizer=self.tokenizer,device = self.device,grouped_entities=True)
    
        self.irr_char =  {
            'en': r'[^\x00-\x7F₹]+',
            'hi': r'[^\u0900-\u097F\x00-\x7F₹]+',
            'ml': r'[^\u0D00-\u0D7F\x00-\x7F₹]+',
            'te': r'[^\x00-\x7F₹\u0C00-\u0C7F]+',
            'mr': r'[^\u0900-\u097F\x00-\x7F₹]+',
            'or': r'[^\u0B00-\u0B7F\x00-\x7F₹]+',
            'ta': r'[^\x00-\x7F₹\u0B80-\u0BFF]+',
            'kn': r'[^\x00-\x7F₹\u0C80-\u0CFF]+',
            'pa': r'[^\u0A00-\u0A7F\x00-\x7F₹]+',
            'bn': r'[^\u0980-\u09FF\x00-\x7F₹]+',
            'gu': r'[^\u0A80-\u0AFF\x00-\x7F₹]+',
        }
    
        # self.ne_processing = NamedEntityPostProcessing()
        
    
    
    def preprocess(self, requests):
        # logger.info(f'post_r:{requests}')
        if type(requests[0]["body"]) == str:
            requests = json.loads(requests[0]["body"])
            language = requests.get("language")
            title = requests.get("title")
            chunk_1 = requests.get("html_chunk_1")
            chunk_2 = requests.get("html_chunk_2")
        elif type(requests[0]["body"]) == dict:
            language = requests[0]["body"].get("language")
            title = requests[0]["body"].get("title")
            chunk_1 = requests[0]["body"].get("html_chunk_1")
            chunk_2 = requests[0]["body"].get("html_chunk_2")

        logger.info(f'language:{language}')
        # logger.info('preprocess done')
        
        if language == 'hi':
            title = indic_preprocessing(title,language)
            chunk_1 = preprocess_span(chunk_1)
            chunk_1 = indic_preprocessing(chunk_1,language)
            chunk_2 = indic_preprocessing(chunk_2,language)
            chunk_1, chunk_2 = get_custom_chunks(chunk_1, chunk_2)
        
        else:
            title = indic_preprocessing(title,language)
            chunk_1 = preprocess_span(chunk_1)
            chunk_1 = indic_preprocessing(chunk_1,language)
            chunk_2 = indic_preprocessing(chunk_2,language)
            
        return title,chunk_1,chunk_2,language
    

    def split_text_into_chunks(self,text,language):
        sentences = sentence_tokenize.sentence_split(text, language, delim_pat='auto')
        # Initialize variables to keep track of chunks
        max_chunk_length = 450
        current_chunk = ""
        chunks = []
        # Iterate through the sentences
        for sentence in sentences:
            # Check if adding the current sentence to the current chunk would exceed the maximum token length
            if len(self.tokenizer(current_chunk + sentence)["input_ids"]) > max_chunk_length:
                # If yes, start a new chunk
                chunks.append(current_chunk)
                current_chunk = ""
        
            # Add the current sentence to the current chunk
            if current_chunk:
                current_chunk += ". "
            current_chunk += sentence
        
        if current_chunk:
            chunks.append(current_chunk)
    
        return chunks
    
    
    def inference(self, inputs):
        # logger.info('inference started')
        output_text = {}
        title, chunk_1, chunk_2 = inputs[0], inputs[1], inputs[2]
        # logger.info(f'inputs_title:{title}')
    
        
        language = inputs[3]
        chunks = [title, chunk_1, chunk_2]
        i = 0
        for text in chunks:
            if i==0:
                # logger.info(f'inputs_title:{text}')
                result = self.classifier(text)
                # logger.info(f'result_title:{result}')
                # op_ners_final = recreate_ners(result, language, self.irr_char)
                op_ners_final = [i['word'] for i in result]
                # logger.info(f'op_ners_final:{op_ners_final}')
            if i==1 or i==2:
                # logger.info(f'inputs_chunk_1or2:{text}')
                op_ners=[]
                chunks = self.split_text_into_chunks(text,language)
                # logger.info(f'no of chunks:{len(chunks)}')
                results_2d =[]
                for chunk in chunks:
                    results_chunk = self.classifier(chunk)
                    op_ner = [i['word'] for i in results_chunk]
                    # op_ner = recreate_ners(results_chunk, language, self.irr_char)
                    op_ners.append(op_ner)

                op_ners_final = [element for sublist in op_ners for element in sublist] 
                
            op_ners_final = [i.lower() for i in op_ners_final]
            op_ners_final = [word for word in op_ners_final if len(word) > 1]


            
                #xlm gives '.' dot also as an ner
                    
                # output_text.append(op_ners)
            logger.info(f'final_ners:{op_ners_final}')
            if language == 'en':
                op_ners_final = [' '.join(re.sub(r'[^\w\s]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']
            if language == 'hi':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0900-\u097F]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'kn':
                # logger.info(f'op_ners_how:{op_ners_final}')
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0C80-\u0CFF]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'te':
                # logger.info(f'op_ners_how:{op_ners_final}')
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0C00-\u0C7F]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'ml':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0D00-\u0D7F]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'mr':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0900-\u097F]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language =='or':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0B00-\u0B7F]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'ta':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0B80-\u0BFF]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'pa':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0A00-\u0A7F]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'bn':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0980-\u09FF]+', '', word.strip()) for word in s.split()).replace('_', ' ')for s in op_ners_final if s != '.' and s.strip() != '']

            if language == 'gu':
                op_ners_final = [' '.join(re.sub(r'[^\w\s\u0A80-\u0AFF]+', '', word.strip()) for word in s.split()).replace('_', ' ') for s in op_ners_final if s != '.' and s.strip() != '']
                
     
            op_ners_final = [' '.join(re.sub(r'\s+', ' ', word) for word in s.split()) for s in op_ners_final]
            op_ners_final = [s for s in op_ners_final if s]

            
            if language == 'hi' or language == 'en':  # Fix this line to properly compare 'language'
                ner_names = dedup_ne_list(op_ners_final)
            else:
                ner_names = match_entities(op_ners_final,language)                    
                               
            if i == 0:
                output_text['title'] = ner_names 
            if i == 1:
               output_text['html_chunk_1'] = ner_names
            if i == 2:
                output_text['html_chunk_2'] = ner_names
               
            i = i + 1
            
        return output_text
    

    
    
    def postprocess(self, outputs):
        # logger.info('in postprocess') 
        # for key in outputs:
        #     outputs[key] = {inner_key: inner_value for inner_key, inner_value in outputs[key].items() if len(inner_key) > 1}
        # outputs = {key: value for key, value in outputs.items() if len(value) > 1}
        logger.info(f'ners:{outputs}')
        
        return [outputs]
        # postprocess the outputs of the model as you wish and then send it as response its important to return it as
        # a list of list as only one item per batch we are serving and the returning list sould be of len 1
        # return [outputs]

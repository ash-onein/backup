# import sys, string, itertools, re, os
from collections import defaultdict

# from indicnlp import common
import langinfo
# from indicnlp.script import indic_scripts as isc
from sinhala_transliterator import SinhalaDevanagariTransliterator as sdt
import pandas as pd

OFFSET_TO_ITRANS = {}
ITRANS_TO_OFFSET = defaultdict(list)

DUPLICATE_ITRANS_REPRESENTATIONS = {}


def init():
    """
    To be called by library loader, do not call it in your program
    """

    ### Load the ITRANS-script offset map. The map was initially generated using the snippet below (uses the old itrans transliterator)
    ### The map is modified as needed to accomodate extensions and corrections to the mappings
    #
    # base=0x900
    # l=[]
    # for i in range(0,0x80):
    #     c=chr(base+i)
    #     itrans=ItransTransliterator.to_itrans(c,'hi')
    #     l.append((hex(i),c,itrans))
    # print(l)
    #
    # pd.DataFrame(l,columns=['offset_hex','devnag_char','itrans']).to_csv('offset_itrans_map.csv',index=False,encoding='utf-8')

    # itrans_map_fname = os.path.join(common.get_resources_path(), 'transliterate', 'offset_itrans_map.csv')
    # itrans_map_fname=r'D:\src\python_sandbox\src\offset_itrans_map.csv'
    itrans_map_fname = './ml_engine/preprocessing/indic_sentence_tokenize/offset_itrans_map.csv'
    itrans_df = pd.read_csv(itrans_map_fname, encoding='utf-8')

    global OFFSET_TO_ITRANS, ITRANS_TO_OFFSET, DUPLICATE_ITRANS_REPRESENTATIONS

    for r in itrans_df.iterrows():
        itrans = r[1]['itrans']
        o = int(r[1]['offset_hex'], base=16)

        OFFSET_TO_ITRANS[o] = itrans

        if langinfo.is_consonant_offset(o):
            ### for consonants, strip the schwa - add halant offset
            ITRANS_TO_OFFSET[itrans[:-1]].extend([o, 0x4d])
        else:
            ### the append assumes that the maatra always comes after independent vowel in the df
            ITRANS_TO_OFFSET[itrans].append(o)

        DUPLICATE_ITRANS_REPRESENTATIONS = {
            'A': 'aa',
            'I': 'ii',
            'U': 'uu',
            'RRi': 'R^i',
            'RRI': 'R^I',
            'LLi': 'L^i',
            'LLI': 'L^I',
            'L': 'ld',
            'w': 'v',
            'x': 'kSh',
            'gj': 'j~n',
            'dny': 'j~n',
            '.n': '.m',
            'M': '.m',
            'OM': 'AUM'
        }


class UnicodeIndicTransliterator(object):
    """
    Base class for rule-based transliteration among Indian languages.

    Script pair specific transliterators should derive from this class and override the transliterate() method.
    They can call the super class 'transliterate()' method to avail of the common transliteration
    """

    @staticmethod
    def _correct_tamil_mapping(offset):
        # handle missing unaspirated and voiced plosives in Tamil script
        # replace by unvoiced, unaspirated plosives

        # for first 4 consonant rows of varnamala
        # exception: ja has a mapping in Tamil
        if offset >= 0x15 and offset <= 0x28 and \
                offset != 0x1c and \
                not ((offset - 0x15) % 5 == 0 or (offset - 0x15) % 5 == 4):
            subst_char = (offset - 0x15) // 5
            offset = 0x15 + 5 * subst_char

        # for 5th consonant row of varnamala
        if offset in [0x2b, 0x2c, 0x2d]:
            offset = 0x2a

        # 'sh' becomes 'Sh'
        if offset == 0x36:
            offset = 0x37

        return offset

    @staticmethod
    def transliterate(text, lang1_code, lang2_code):
        """
        convert the source language script (lang1) to target language script (lang2)

        text: text to transliterate
        lang1_code: language 1 code
        lang1_code: language 2 code
        """
        if lang1_code in langinfo.SCRIPT_RANGES and lang2_code in langinfo.SCRIPT_RANGES:

            # if Sinhala is source, do a mapping to Devanagari first
            if lang1_code == 'si':
                text = sdt.sinhala_to_devanagari(text)
                lang1_code = 'hi'

            # if Sinhala is target, make Devanagiri the intermediate target
            org_lang2_code = ''
            if lang2_code == 'si':
                lang2_code = 'hi'
                org_lang2_code = 'si'

            trans_lit_text = []
            for c in text:
                newc = c
                offset = ord(c) - langinfo.SCRIPT_RANGES[lang1_code][0]
                if offset >= langinfo.COORDINATED_RANGE_START_INCLUSIVE and offset <= langinfo.COORDINATED_RANGE_END_INCLUSIVE and c != '\u0964' and c != '\u0965':
                    if lang2_code == 'ta':
                        # tamil exceptions
                        offset = UnicodeIndicTransliterator._correct_tamil_mapping(offset)
                    newc = chr(langinfo.SCRIPT_RANGES[lang2_code][0] + offset)

                trans_lit_text.append(newc)

                # if Sinhala is source, do a mapping to Devanagari first
            if org_lang2_code == 'si':
                return sdt.devanagari_to_sinhala(''.join(trans_lit_text))

            return ''.join(trans_lit_text)
        else:
            return text
# XLM-Roberta Named Entity Recognition

## Overview

 **XLM-Roberta NER** This repository provides documentation and guidelines for using the XLM-RoBERTa NER (Named Entity Recognition) model. The XLM-RoBERTa model is a state-of-the-art multilingual pre-trained model developed by Facebook AI that can be used for various natural language processing tasks, including NER.


## Getting Started

Follow these steps to get started with the **XLM-NER model:

1. Download the Repo:
   - (https://gitlab.dailyhunt.in/rishab.jain/xlm-roberta-ner.git)

2. Download the model and tokenizer by
```
import torch
from transformers import AutoModelForTokenClassification, AutoTokenizer

# Load the model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
tokenizer = AutoTokenizer.from_pretrained("xlm-roberta-large-finetuned-conll03-english")
model = AutoModelForTokenClassification.from_pretrained("xlm-roberta-large-finetuned-conll03-english")

# saving model 
tokenizer.save_pretrained("./tokenizer")
model.save_pretrained("./model")
```
3. now you need to create a .mar file which torch model archive which encapsulates all the required files and tools into
one file which will inturn be used by the torch serve:

```

torch-model-archiver --model-name xlm-net --version 1.0  --model-file model/pytorch_model.bin  --handler model_handler.py  --extra-files "tokenizer/tokenizer.json,tokenizer/special_tokens_map.json,tokenizer/tokenizer_config.json,model/config.json,helper_functions.py,text_preprocessing.py,__init__.py,langinfo.py,offset_itrans_map.csv,sentence_tokenize.py,sinhala_transliterator.py,unicode_transliterate.py" --export-path model_store

```

4. Run torchserve by 

```
torchserve --start --ncs --model-store model_store --models xlm-net=xlm-net.mar --ts-config config.properties
```
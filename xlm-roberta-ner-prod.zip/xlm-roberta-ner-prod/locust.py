from locust import HttpUser, task, between

class APILoadTest(HttpUser):
    wait_time = between(1, 2)  # Define the wait time between tasks (1-2 seconds)

    @task
    def predict_xlm_net(self):
        url = "/predictions/xlm-net/1.0"
        headers = {"Content-Type": "application/json"}
        payload = {
            "title": "जब जब धरती पर पाप और अधर्म हद से ज्यादा बढ़ा है, भगवान ने धरती पर अवतार लिया है। भगवान विष्णु किसी न किसी उद्देश्य की पूर्ति के लिए धरती पर अवतरित हुए। विष्णु जी का एक अवतार श्रीकृष्ण थे। मथुरा की राजकुमारी देवकी और वासुदेव",
            "html_chunk_1": "जब जब धरती पर पाप और अधर्म हद से ज्यादा बढ़ा है, भगवान ने धरती पर अवतार लिया है। भगवान विष्णु किसी न किसी उद्देश्य की पूर्ति के लिए धरती पर अवतरित हुए। विष्णु जी का एक अवतार श्रीकृष्ण थे। मथुरा की राजकुमारी देवकी और वासुदेव",
            "html_chunk_2": "जब जब धरती पर पाप और अधर्म हद से ज्यादा बढ़ा है, भगवान ने धरती पर अवतार लिया है। भगवान विष्णु किसी न किसी उद्देश्य की पूर्ति के लिए धरती पर अवतरित हुए। विष्णु जी का एक अवतार श्रीकृष्ण थे। मथुरा की राजकुमारी देवकी और वासुदेव",
            "language": "hi",
        }
        response = self.client.post(url, headers=headers, json=payload)
        if response.status_code == 200:
            # Successful response
            self.environment.runner.stats.log_request_success(
                request_type="POST",
                name=url,
                response_time=response.elapsed.total_seconds() * 1000,  # in milliseconds
                response_length=len(response.content),
            )
        else:
            # Unsuccessful response
            self.environment.runner.stats.log_request_failure(
                request_type="POST",
                name=url,
                response_time=response.elapsed.total_seconds() * 1000,  # in milliseconds
                exception=response.text,
            )
